import React, { useState, useEffect } from 'react';
import { ActivityData } from '../types';

interface ActivityLogProps {
  onUpdate: (data: ActivityData) => void;
  initialData: ActivityData;
}

const ActivityLog: React.FC<ActivityLogProps> = ({ onUpdate, initialData }) => {
  const [data, setData] = useState<ActivityData>(initialData);

  const handleChange = (field: keyof ActivityData, value: number) => {
    const newData = { ...data, [field]: value };
    setData(newData);
    onUpdate(newData);
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
      <h2 className="text-xl font-bold text-slate-800 mb-4 flex items-center gap-2">
        <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-indigo-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
        </svg>
        Activity & Sleep Tracker
      </h2>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Steps */}
        <div className="space-y-2">
          <label className="text-sm font-medium text-slate-600">Daily Steps</label>
          <div className="flex items-center gap-4">
            <input
              type="range"
              min="0"
              max="20000"
              step="500"
              value={data.steps}
              onChange={(e) => handleChange('steps', parseInt(e.target.value))}
              className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-indigo-600"
            />
            <span className="w-20 text-right font-bold text-slate-800">{data.steps}</span>
          </div>
        </div>

        {/* Heart Rate */}
        <div className="space-y-2">
          <label className="text-sm font-medium text-slate-600">Avg Heart Rate (BPM)</label>
          <div className="flex items-center gap-4">
            <input
              type="range"
              min="40"
              max="140"
              value={data.heartRateAvg}
              onChange={(e) => handleChange('heartRateAvg', parseInt(e.target.value))}
              className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-rose-500"
            />
            <span className="w-20 text-right font-bold text-slate-800">{data.heartRateAvg}</span>
          </div>
        </div>

        {/* Sleep Hours */}
        <div className="space-y-2">
          <label className="text-sm font-medium text-slate-600">Sleep Duration (Hours)</label>
          <div className="flex items-center gap-4">
            <button 
              onClick={() => handleChange('sleepHours', Math.max(0, data.sleepHours - 0.5))}
              className="p-1 rounded bg-slate-100 hover:bg-slate-200"
            >
              -
            </button>
            <span className="flex-1 text-center font-bold text-2xl text-slate-800">{data.sleepHours}</span>
            <button 
               onClick={() => handleChange('sleepHours', Math.min(14, data.sleepHours + 0.5))}
               className="p-1 rounded bg-slate-100 hover:bg-slate-200"
            >
              +
            </button>
          </div>
        </div>

        {/* Sleep Quality */}
        <div className="space-y-2">
          <label className="text-sm font-medium text-slate-600">Sleep Quality (1-10)</label>
          <div className="flex justify-between items-center bg-slate-50 p-3 rounded-lg">
            {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((num) => (
              <button
                key={num}
                onClick={() => handleChange('sleepQuality', num)}
                className={`w-8 h-8 rounded-full text-xs font-bold transition-all ${
                  data.sleepQuality === num
                    ? 'bg-indigo-600 text-white scale-110 shadow-md'
                    : 'bg-white text-slate-500 hover:bg-indigo-50'
                }`}
              >
                {num}
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ActivityLog;
