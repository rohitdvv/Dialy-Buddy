import React, { useState, useRef } from 'react';
import { JournalData } from '../types';
import { analyzeJournalEntry } from '../services/geminiService';

interface VoiceJournalProps {
  onAddEntry: (entry: JournalData) => void;
  entries: JournalData[];
}

const VoiceJournal: React.FC<VoiceJournalProps> = ({ onAddEntry, entries }) => {
  const [isRecording, setIsRecording] = useState(false);
  const [textInput, setTextInput] = useState('');
  const [processing, setProcessing] = useState(false);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      mediaRecorderRef.current = new MediaRecorder(stream);
      chunksRef.current = [];

      mediaRecorderRef.current.ondataavailable = (e) => {
        if (e.data.size > 0) chunksRef.current.push(e.data);
      };

      mediaRecorderRef.current.onstop = async () => {
        const blob = new Blob(chunksRef.current, { type: 'audio/webm' }); // WebM is standard for recording
        await processAudio(blob);
        // Stop all tracks
        stream.getTracks().forEach(track => track.stop());
      };

      mediaRecorderRef.current.start();
      setIsRecording(true);
    } catch (err) {
      console.error("Error accessing microphone:", err);
      alert("Microphone access denied. Please use text input.");
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
    }
  };

  const processAudio = async (blob: Blob) => {
    setProcessing(true);
    try {
      const base64Data = await new Promise<string>((resolve) => {
        const reader = new FileReader();
        reader.readAsDataURL(blob);
        reader.onloadend = () => {
          const result = reader.result as string;
          resolve(result.split(',')[1]);
        };
      });

      // Send to Gemini as audio
      const data = await analyzeJournalEntry("", base64Data);
      onAddEntry(data);
    } catch (e) {
      alert("Failed to process audio journal.");
    } finally {
      setProcessing(false);
    }
  };

  const handleTextSubmit = async () => {
    if (!textInput.trim()) return;
    setProcessing(true);
    try {
      const data = await analyzeJournalEntry(textInput);
      onAddEntry(data);
      setTextInput('');
    } catch (e) {
      alert("Failed to process text entry.");
    } finally {
      setProcessing(false);
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      <div className="lg:col-span-1 space-y-6">
        {/* Record Card */}
        <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200 text-center">
          <h2 className="text-xl font-bold text-slate-800 mb-6">Voice Journal</h2>
          
          <div className="flex justify-center mb-6">
            <button
              onClick={isRecording ? stopRecording : startRecording}
              disabled={processing}
              className={`w-24 h-24 rounded-full flex items-center justify-center transition-all ${
                isRecording 
                  ? 'bg-red-500 shadow-[0_0_0_10px_rgba(239,68,68,0.2)] animate-pulse' 
                  : 'bg-indigo-600 hover:bg-indigo-700 shadow-lg hover:scale-105'
              } disabled:opacity-50 disabled:cursor-not-allowed`}
            >
              {processing ? (
                 <svg className="animate-spin h-8 w-8 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                   <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                   <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                 </svg>
              ) : isRecording ? (
                <div className="w-8 h-8 bg-white rounded-sm" />
              ) : (
                <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10 text-white" viewBox="0 0 20 20" fill="currentColor">
                  <path fillRule="evenodd" d="M7 4a3 3 0 016 0v4a3 3 0 11-6 0V4zm4 10.93A7.001 7.001 0 0017 8a1 1 0 10-2 0A5 5 0 015 8a1 1 0 00-2 0 7.001 7.001 0 006 6.93V17H6a1 1 0 100 2h8a1 1 0 100-2h-3v-2.07z" clipRule="evenodd" />
                </svg>
              )}
            </button>
          </div>
          <p className="text-slate-500 text-sm">
            {isRecording ? "Listening... Tap to stop" : processing ? "Analyzing emotions..." : "Tap to record your thoughts"}
          </p>
        </div>

        {/* Text Fallback */}
        <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
           <h3 className="font-semibold text-slate-700 mb-2">Or type your entry</h3>
           <textarea
             className="w-full p-3 border border-slate-200 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-none text-sm"
             rows={4}
             placeholder="How are you feeling today?"
             value={textInput}
             onChange={(e) => setTextInput(e.target.value)}
             disabled={processing || isRecording}
           />
           <button 
            onClick={handleTextSubmit}
            disabled={!textInput.trim() || processing}
            className="mt-2 w-full bg-slate-800 text-white py-2 rounded-lg text-sm font-medium hover:bg-slate-900 disabled:opacity-50"
           >
             Analyze Text
           </button>
        </div>
      </div>

      <div className="lg:col-span-2 bg-white p-6 rounded-xl shadow-sm border border-slate-200 h-full overflow-y-auto max-h-[600px]">
        <h3 className="text-lg font-bold text-slate-800 mb-4">Emotional Insights</h3>
        {entries.length === 0 ? (
          <div className="text-center text-slate-400 py-12">No journal entries yet.</div>
        ) : (
          <div className="space-y-4">
            {entries.map((entry, idx) => (
              <div key={idx} className="border-l-4 border-indigo-500 bg-slate-50 p-4 rounded-r-lg">
                <div className="flex justify-between items-start mb-2">
                  <div className="flex gap-2 items-center">
                    <span className="font-bold text-slate-800 uppercase text-sm tracking-wide">{entry.mood}</span>
                    <span className="text-xs px-2 py-0.5 rounded-full bg-white border border-slate-200 text-slate-500">
                      Stress: {entry.stressLevel}/10
                    </span>
                  </div>
                  <div className="text-xs text-slate-400">
                    Sentiment: {entry.sentimentScore.toFixed(2)}
                  </div>
                </div>
                <p className="text-slate-600 text-sm italic mb-3">"{entry.summary}"</p>
                <div className="flex flex-wrap gap-2">
                  {entry.keyTopics.map((topic, i) => (
                    <span key={i} className="text-xs bg-indigo-100 text-indigo-700 px-2 py-1 rounded-md">
                      #{topic}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default VoiceJournal;
