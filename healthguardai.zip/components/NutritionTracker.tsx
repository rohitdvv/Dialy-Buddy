import React, { useState } from 'react';
import { NutritionData } from '../types';
import { analyzeFoodImage } from '../services/geminiService';

interface NutritionTrackerProps {
  onAddEntry: (entry: NutritionData) => void;
  entries: NutritionData[];
}

const NutritionTracker: React.FC<NutritionTrackerProps> = ({ onAddEntry, entries }) => {
  const [analyzing, setAnalyzing] = useState(false);
  const [preview, setPreview] = useState<string | null>(null);

  const handleFileChange = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    // Preview
    const reader = new FileReader();
    reader.onloadend = () => {
      setPreview(reader.result as string);
    };
    reader.readAsDataURL(file);

    // Analyze
    setAnalyzing(true);
    try {
      const base64Data = await new Promise<string>((resolve, reject) => {
        const r = new FileReader();
        r.readAsDataURL(file);
        r.onload = () => resolve((r.result as string).split(',')[1]);
        r.onerror = (error) => reject(error);
      });

      const data = await analyzeFoodImage(base64Data, file.type);
      onAddEntry(data);
      setPreview(null); // Clear preview after successful add
    } catch (err) {
      alert("Failed to analyze image. Please try again.");
    } finally {
      setAnalyzing(false);
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      {/* Upload Section */}
      <div className="lg:col-span-1 space-y-4">
        <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
          <h2 className="text-xl font-bold text-slate-800 mb-4 flex items-center gap-2">
             <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" />
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 13a3 3 0 11-6 0 3 3 0 016 0z" />
            </svg>
            Log Meal
          </h2>
          
          <div className="border-2 border-dashed border-slate-300 rounded-lg p-6 text-center hover:bg-slate-50 transition-colors relative">
             {preview ? (
                <div className="relative">
                  <img src={preview} alt="Preview" className="w-full h-48 object-cover rounded-lg" />
                  {analyzing && (
                    <div className="absolute inset-0 bg-black/50 flex items-center justify-center rounded-lg">
                      <div className="text-white font-semibold animate-pulse">Analyzing with Gemini...</div>
                    </div>
                  )}
                </div>
             ) : (
               <>
                <p className="text-slate-500 mb-2">Drag & drop or click to upload food photo</p>
                <input 
                  type="file" 
                  accept="image/*" 
                  onChange={handleFileChange} 
                  className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                  disabled={analyzing}
                />
                <button className="bg-slate-100 text-slate-600 px-4 py-2 rounded-md font-medium text-sm">
                  Select Image
                </button>
               </>
             )}
          </div>
        </div>
      </div>

      {/* History Section */}
      <div className="lg:col-span-2">
        <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200 h-full">
           <h3 className="text-lg font-bold text-slate-800 mb-4">Today's Nutrition</h3>
           {entries.length === 0 ? (
             <div className="text-center text-slate-400 py-12">No meals logged yet today.</div>
           ) : (
             <div className="space-y-4">
               {entries.map((entry, idx) => (
                 <div key={idx} className="flex flex-col sm:flex-row gap-4 p-4 rounded-lg bg-slate-50 border border-slate-100">
                    <div className="flex-1">
                      <div className="flex justify-between items-start">
                        <h4 className="font-bold text-slate-800 text-lg capitalize">{entry.foodName}</h4>
                        <span className={`px-2 py-1 rounded text-xs font-bold ${
                          entry.healthScore > 80 ? 'bg-green-100 text-green-700' :
                          entry.healthScore > 50 ? 'bg-yellow-100 text-yellow-700' :
                          'bg-red-100 text-red-700'
                        }`}>Score: {entry.healthScore}</span>
                      </div>
                      <p className="text-sm text-slate-600 mt-1">{entry.analysis}</p>
                      <div className="mt-3 flex gap-4 text-sm text-slate-500">
                        <span>🔥 {entry.calories} kcal</span>
                        <span>🥩 {entry.protein}g P</span>
                        <span>🍞 {entry.carbs}g C</span>
                        <span>🥑 {entry.fat}g F</span>
                      </div>
                    </div>
                 </div>
               ))}
             </div>
           )}
        </div>
      </div>
    </div>
  );
};

export default NutritionTracker;
